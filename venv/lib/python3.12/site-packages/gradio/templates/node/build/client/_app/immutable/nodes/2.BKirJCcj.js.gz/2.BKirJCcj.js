import { V, _ } from "../chunks/2.BUksOkfw.js";
export {
  V as component,
  _ as universal
};
